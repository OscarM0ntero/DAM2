import { Component } from '@angular/core';
import { ListaComponent } from '../lista/lista.component';

@Component({
  selector: 'dbz-add-personaje',
  templateUrl: './add-personaje.component.html',
  styleUrl: './add-personaje.component.css'
})
export class AddPersonajeComponent {
  pila: any[] = [];
  indiceActual = 0;

  insertarPersonaje() {
    if (this.pila.length > 0) {
      const personaje = this.pila.pop();
      ListaComponent.personajes.splice(this.indiceActual, 0, personaje);
    }
  }
}
