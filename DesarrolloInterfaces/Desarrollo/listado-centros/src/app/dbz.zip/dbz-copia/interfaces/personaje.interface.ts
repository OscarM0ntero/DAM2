export interface Personaje
{
  nombre: string;
  fuerza: number;
 }
