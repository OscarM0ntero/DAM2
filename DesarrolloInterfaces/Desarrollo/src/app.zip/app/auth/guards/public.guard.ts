import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';  // Servicio de autenticación

@Injectable({
  providedIn: 'root'
})
export class PublicGuard implements CanActivate {

  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {

    // Verifica si el usuario está autenticado
    if (this.authService.checkAuth()) {
      // Si está autenticado, redirige a la página de héroes
      this.router.navigate(['/heroes']);
      return false; // No permite cargar la pantalla de login
    }

    // Si no está autenticado, permite el acceso a la pantalla de login
    return true;
  }
}
