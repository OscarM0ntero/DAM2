export interface User {
  id: string;
  nombre: string;
  usuario: string;
}
