import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Error404PageComponent } from './shared/pages/error404-page/error404-page.component';
import { PublicGuard } from './auth/guards/public.guard'; // Importa el PublicGuard
import { canActivateGuard, canMatchGuard } from './auth/guards/auth.guard';

const routes: Routes = [
  {
    path: 'auth',  // Ruta para autenticación
    loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule),  // Carga el módulo de autenticación
    canActivate: [PublicGuard],  // Aplica el PublicGuard para redirigir si está autenticado
  },
  {
    path: 'heroes',
    loadChildren: () => import('./heroes/heroes.module').then(m => m.HeroesModule),  // Carga el módulo de héroes
    canActivate: [canActivateGuard],  // Protege la ruta de héroes
    canMatch: [canMatchGuard],  // Protege la ruta de héroes
  },
  {
    path: '404',
    component: Error404PageComponent,  // Componente de error
  },
  {
    path: '',
    redirectTo: '/heroes',  // Redirige por defecto a los héroes
    pathMatch: 'full',
  },
  {
    path: '**',  // Redirige cualquier ruta no definida a la página 404
    redirectTo: '404',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
