const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const driver = require('./neo4j_driver');
const fs = require('fs');
const session = require('express-session');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key', // Cambia esto por una clave secreta más segura
    resave: false,
    saveUninitialized: true
}));

// Configurar Multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, 'public/uploads');
        if (!fs.existsSync(uploadDir)){
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Función para obtener o crear el nodo de la imagen predeterminada
const getDefaultProfileImageNode = async () => {
    const session = driver.session();
    const defaultProfileImagePath = '/uploads/default_profile.gif';

    try {
        const result = await session.run(
            `MATCH (i:Imagen {url: $url}) RETURN i`,
            { url: defaultProfileImagePath }
        );

        if (result.records.length === 0) {
            await session.run(
                `CREATE (i:Imagen {id_imagen: apoc.create.uuid(), url: $url})`,
                { url: defaultProfileImagePath }
            );
            console.log('Nodo de imagen predeterminada creado.');
        } else {
            console.log('El nodo de imagen predeterminada ya existe.');
        }
        
        const defaultImageNode = await session.run(
            `MATCH (i:Imagen {url: $url}) RETURN i`,
            { url: defaultProfileImagePath }
        );

        return defaultImageNode.records[0].get('i');
    } catch (error) {
        console.error('Error al crear/verificar el nodo de imagen predeterminada:', error);
    } finally {
        await session.close();
    }
};

app.post('/register', upload.single('profileImage'), async (req, res) => {
    const { username, password, biography } = req.body;
    
    if (username.length > 15) {
        res.json({ error: 'El nombre de usuario no puede tener más de 15 caracteres.' });
        return;
    }

    const profileImage = req.file ? `/uploads/${req.file.filename}` : '';
    const session = driver.session();

    try {
        // Verificar si el nombre de usuario ya existe
        const userCheckResult = await session.run(
            `MATCH (u:Usuario {user_name: $username}) RETURN u`,
            { username }
        );

        if (userCheckResult.records.length > 0) {
            res.json({ error: 'Username is already taken' });
            return;
        }

        let profileImageUrl = profileImage;

        if (!profileImage) {
            const defaultImageNode = await getDefaultProfileImageNode();
            profileImageUrl = defaultImageNode.properties.url;
        }

        const createUserResult = await session.run(
            `CREATE (u:Usuario {id_usuario: apoc.create.uuid(), user_name: $username, password: $password, biography: $biography, register_date: datetime()})
            RETURN u`,
            { username, password, biography }
        );

        const userId = createUserResult.records[0].get('u').properties.id_usuario;

        if (profileImage) {
            await session.run(
                `MATCH (u:Usuario {id_usuario: $userId})
                 CREATE (i:Imagen {id_imagen: apoc.create.uuid(), url: $profileImageUrl})
                 CREATE (u)-[:TIENE_IMAGEN_DE_PERFIL]->(i)`,
                { userId, profileImageUrl }
            );
        } else {
            await session.run(
                `MATCH (u:Usuario {id_usuario: $userId})
                 MATCH (i:Imagen {url: $profileImageUrl})
                 CREATE (u)-[:TIENE_IMAGEN_DE_PERFIL]->(i)`,
                { userId, profileImageUrl }
            );
        }

        res.json({ success: true });
    } catch (error) {
        console.error('Error during registration:', error);
        res.json({ error: 'Error during registration' });
    } finally {
        await session.close();
    }
});



app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {user_name: $username, password: $password}) RETURN u.id_usuario AS id_usuario`,
            { username, password }
        );

        if (result.records.length > 0) {
            req.session.userId = result.records[0].get('id_usuario');
            res.json({ id_usuario: result.records[0].get('id_usuario') });
        } else {
            res.json({ error: 'Invalid credentials' });
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.json({ error: 'Error during login' });
    } finally {
        await session.close();
    }
});

app.post('/post', upload.single('postImage'), async (req, res) => {
    const { content, user_id } = req.body;
    const postImage = req.file ? `/uploads/${req.file.filename}` : '';
    const session = driver.session();

    try {
        const postResult = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})
             CREATE (p:Post {id_post: apoc.create.uuid(), content: $content, post_date: datetime()})
             MERGE (u)-[:PUBLICA]->(p)
             RETURN p.id_post AS id_post`,
            { content, user_id }
        );

        const postId = postResult.records[0].get('id_post');

        if (postImage) {
            await session.run(
                `MATCH (p:Post {id_post: $postId})
                 CREATE (i:Imagen {id_imagen: apoc.create.uuid(), url: $postImage})
                 MERGE (p)-[:TIENE_IMAGEN]->(i)`,
                { postId, postImage }
            );
        }

        res.json({ success: true });
    } catch (error) {
        console.error('Error during posting:', error);
        res.json({ error: 'Error during posting' });
    } finally {
        await session.close();
    }
});

app.get('/user/profile', async (req, res) => {
    const { user_id } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})
             OPTIONAL MATCH (u)-[:TIENE_IMAGEN_DE_PERFIL]->(i:Imagen)
             RETURN u.user_name AS username, u.biography AS biography, i.url AS profileImage`,
            { user_id }
        );

        if (result.records.length > 0) {
            const record = result.records[0];
            res.json({
                username: record.get('username'),
                biography: record.get('biography'),
                profileImage: record.get('profileImage')
            });
        } else {
            res.json({ error: 'User not found' });
        }
    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.json({ error: 'Error fetching user profile' });
    } finally {
        await session.close();
    }
});

app.post('/editProfile', upload.single('profileImage'), async (req, res) => {
    const { user_id, username, biography } = req.body;
    
    if (username.length > 15) {
        res.json({ error: 'El nombre de usuario no puede tener más de 15 caracteres.' });
        return;
    }

    const profileImage = req.file ? `/uploads/${req.file.filename}` : '';
    const session = driver.session();

    try {
        const checkUsernameResult = await session.run(
            `MATCH (u:Usuario {user_name: $username}) WHERE u.id_usuario <> $user_id RETURN u`,
            { username, user_id }
        );

        if (checkUsernameResult.records.length > 0) {
            res.json({ error: 'Username is already taken' });
            return;
        }

        const updateQuery = `
            MATCH (u:Usuario {id_usuario: $user_id})
            SET u.user_name = $username, u.biography = $biography
            WITH u
            OPTIONAL MATCH (u)-[r:TIENE_IMAGEN_DE_PERFIL]->(i:Imagen)
            DELETE r
            WITH u
            MERGE (newImage:Imagen {url: $profileImage})
            CREATE (u)-[:TIENE_IMAGEN_DE_PERFIL]->(newImage)
            RETURN u, newImage
        `;
        await session.run(updateQuery, { user_id, username, biography, profileImage });

        res.json({ success: true });
    } catch (error) {
        console.error('Error editing profile:', error);
        res.json({ error: 'Error editing profile' });
    } finally {
        await session.close();
    }
});


app.get('/isFollowing', async (req, res) => {
    const { follower_id, followee_id } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (follower:Usuario {id_usuario: $follower_id})-[r:SIGUE]->(followee:Usuario {id_usuario: $followee_id})
             RETURN count(r) AS isFollowing`,
            { follower_id, followee_id }
        );
        res.json({ isFollowing: result.records[0].get('isFollowing') > 0 });
    } catch (error) {
        console.error('Error checking follow status:', error);
        res.json({ error: 'Error checking follow status' });
    } finally {
        await session.close();
    }
});

app.post('/follow', async (req, res) => {
    const { follower_id, followee_id } = req.body;
    const session = driver.session();

    try {
        await session.run(
            `MATCH (follower:Usuario {id_usuario: $follower_id}), (followee:Usuario {id_usuario: $followee_id})
             MERGE (follower)-[:SIGUE]->(followee)`,
            { follower_id, followee_id }
        );
        res.json({ success: true });
    } catch (error) {
        console.error('Error following user:', error);
        res.json({ error: 'Error following user' });
    } finally {
        await session.close();
    }
});

app.post('/unfollow', async (req, res) => {
    const { follower_id, followee_id } = req.body;
    const session = driver.session();

    try {
        await session.run(
            `MATCH (follower:Usuario {id_usuario: $follower_id})-[r:SIGUE]->(followee:Usuario {id_usuario: $followee_id})
             DELETE r`,
            { follower_id, followee_id }
        );
        res.json({ success: true });
    } catch (error) {
        console.error('Error unfollowing user:', error);
        res.json({ error: 'Error unfollowing user' });
    } finally {
        await session.close();
    }
});

app.get('/user', async (req, res) => {
    const { username } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {user_name: $username}) RETURN u.id_usuario AS id_usuario, u.user_name AS user_name`,
            { username }
        );

        if (result.records.length > 0) {
            const record = result.records[0];
            res.json({
                id_usuario: record.get('id_usuario'),
                user_name: record.get('user_name')
            });
        } else {
            res.json({ error: 'User not found' });
        }
    } catch (error) {
        console.error('Error fetching user:', error);
        res.json({ error: 'Error fetching user' });
    } finally {
        await session.close();
    }
});

// /mnt/data/server.js

app.get('/user/posts', async (req, res) => {
    const { user_id } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})
             OPTIONAL MATCH (u)-[rel:PUBLICA|REPOSTEA|LE_GUSTA]->(p:Post)
             OPTIONAL MATCH (p)-[:TIENE_IMAGEN]->(img:Imagen)
             OPTIONAL MATCH (p)<-[:PUBLICA]-(author:Usuario)
             OPTIONAL MATCH (author)-[:TIENE_IMAGEN_DE_PERFIL]->(authorImg:Imagen)
             OPTIONAL MATCH (p)<-[:COMENTA]-(c:Comentario)
             OPTIONAL MATCH (c)-[:TIENE_IMAGEN_DE_PERFIL]->(commentImg:Imagen)
             RETURN DISTINCT p, img.url AS postImage, author.user_name AS authorName, authorImg.url AS authorImage, COLLECT(c {.*, commentImage: commentImg.url}) AS comments, EXISTS((u)-[:LE_GUSTA]->(p)) AS likedByUser, EXISTS((u)-[:REPOSTEA]->(p)) AS repostedByUser, TYPE(rel) AS relationshipType
             ORDER BY p.post_date DESC`,
            { user_id }
        );

        const posts = result.records.map(record => {
            const postNode = record.get('p');
            const postDate = postNode.properties.post_date;
            const formattedDate = postDate ? new Date(postDate.year.low, postDate.month.low - 1, postDate.day.low, postDate.hour.low, postDate.minute.low, postDate.second.low, postDate.nanosecond.low / 1000000).toISOString() : null;

            const post = {
                id_post: postNode.properties.id_post,
                content: postNode.properties.content,
                post_date: formattedDate,
                postImage: record.get('postImage') || null,
                authorName: record.get('authorName'),
                authorImage: record.get('authorImage') || 'default_profile.gif',
                comments: record.get('comments').map(comment => ({
                    id_comment: comment.id_comentario,
                    content: comment.content,
                    comment_date: comment.comment_date ? new Date(comment.comment_date.year.low, comment.comment_date.month.low - 1, comment.comment_date.day.low, comment.comment_date.hour.low, comment.comment_date.minute.low, comment.comment_date.second.low, comment.comment_date.nanosecond.low / 1000000).toISOString() : null,
                    username: comment.user_name,
                    profileImageUrl: comment.commentImage || 'default_profile.gif'
                })),
                likedByUser: record.get('likedByUser'),
                repostedByUser: record.get('repostedByUser'),
                relationshipType: record.get('relationshipType') // Añadir el tipo de relación
            };
            return post;
        });

        res.json(posts);
    } catch (error) {
        console.error('Error fetching user posts:', error);
        res.status(500).json({ error: 'Error fetching user posts' });
    } finally {
        await session.close();
    }
});



// /mnt/data/server.js

app.get('/feed', async (req, res) => {
    const { user_id } = req.query;
    const session = driver.session();

    try {
        // Obtener las publicaciones
        const result = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})
             OPTIONAL MATCH (u)-[:SIGUE]->(followee:Usuario)-[:PUBLICA]->(p1:Post)
             OPTIONAL MATCH (followee)-[:TIENE_IMAGEN_DE_PERFIL]->(followeeProfile:Imagen)
             OPTIONAL MATCH (p1)-[:TIENE_IMAGEN]->(p1Image:Imagen)
             WHERE p1 IS NOT NULL
             WITH u, collect({
                 username: followee.user_name,
                 profileImage: followeeProfile.url,
                 postImage: p1Image.url,
                 content: p1.content,
                 post_date: p1.post_date,
                 id_post: p1.id_post,
                 user_id: followee.id_usuario // Añadir user_id
             }) AS followeePosts
             OPTIONAL MATCH (u)-[:PUBLICA]->(p2:Post)
             OPTIONAL MATCH (u)-[:TIENE_IMAGEN_DE_PERFIL]->(userProfile:Imagen)
             OPTIONAL MATCH (p2)-[:TIENE_IMAGEN]->(p2Image:Imagen)
             WHERE p2 IS NOT NULL
             WITH followeePosts + collect({
                 username: u.user_name,
                 profileImage: userProfile.url,
                 postImage: p2Image.url,
                 content: p2.content,
                 post_date: p2.post_date,
                 id_post: p2.id_post,
                 user_id: u.id_usuario // Añadir user_id
             }) AS posts, u
             UNWIND posts AS post
             RETURN post
             ORDER BY post.post_date DESC`, // Ordenar todos los posts juntos
            { user_id }
        );

        let posts = result.records.map(record => {
            const post = record.get('post');
            const postDate = post.post_date;
            return {
                username: post.username,
                profileImage: post.profileImage,
                postImage: post.postImage,
                content: post.content,
                post_date: postDate ? new Date(postDate.year.low, postDate.month.low - 1, postDate.day.low, postDate.hour.low, postDate.minute.low, postDate.second.low, postDate.nanosecond.low / 1000000).toISOString() : null,
                id_post: post.id_post,
                user_id: post.user_id, // Añadir user_id al post
                likedByUser: false, // Inicializar el estado de "Me gusta"
                repostedByUser: false // Inicializar el estado de "Repost"
            };
        });

        // Verificar los estados de "Me gusta"
        const likedResult = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})-[:LE_GUSTA]->(p:Post)
             RETURN p.id_post AS id_post`,
            { user_id }
        );

        const likedPosts = new Set(likedResult.records.map(record => record.get('id_post')));

        // Verificar los estados de "Repost"
        const repostResult = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})-[:REPOSTEA]->(p:Post)
             RETURN p.id_post AS id_post`,
            { user_id }
        );

        const repostedPosts = new Set(repostResult.records.map(record => record.get('id_post')));

        // Actualizar los estados en los posts
        posts = posts.map(post => ({
            ...post,
            likedByUser: likedPosts.has(post.id_post),
            repostedByUser: repostedPosts.has(post.id_post)
        }));

        res.json(posts);
    } catch (error) {
        console.error('Error fetching feed:', error);
        res.json({ error: 'Error fetching feed' });
    } finally {
        await session.close();
    }
});






// Nueva funcionalidad: Manejar "Me gusta" en un post
app.post('/like', async (req, res) => {
    const { postId, userId } = req.body;

    console.log('Like request received:', { postId, userId }); // Depuración

    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (u:Usuario {id_usuario: $userId}), (p:Post {id_post: $postId})
             OPTIONAL MATCH (u)-[r:LE_GUSTA]->(p)
             WITH u, p, r
             WHERE r IS NULL
             CREATE (u)-[:LE_GUSTA]->(p)
             RETURN u, p, r`,
            { userId, postId }
        );

        if (result.records.length === 0) {
            await session.run(
                `MATCH (u:Usuario {id_usuario: $userId})-[r:LE_GUSTA]->(p:Post {id_post: $postId})
                 DELETE r`,
                { userId, postId }
            );
            res.json({ success: true, action: 'unliked' });
        } else {
            res.json({ success: true, action: 'liked' });
        }
    } catch (error) {
        console.error('Error al dar "Me gusta" al post:', error); // Depuración
        res.json({ error: 'Error al dar "Me gusta" al post' });
    } finally {
        await session.close();
    }
});

// Nueva funcionalidad: Manejar "Repost" de un post
app.post('/repost', async (req, res) => {
    const { postId, userId } = req.body;

    console.log('Repost request received:', { postId, userId }); // Depuración

    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (u:Usuario {id_usuario: $userId}), (p:Post {id_post: $postId})
             OPTIONAL MATCH (u)-[r:REPOSTEA]->(p)
             WITH u, p, r
             WHERE r IS NULL
             CREATE (u)-[:REPOSTEA]->(p)
             RETURN u, p, r`,
            { userId, postId }
        );

        if (result.records.length === 0) {
            await session.run(
                `MATCH (u:Usuario {id_usuario: $userId})-[r:REPOSTEA]->(p:Post {id_post: $postId})
                 DELETE r`,
                { userId, postId }
            );
            res.json({ success: true, action: 'unreposted' });
        } else {
            res.json({ success: true, action: 'reposted' });
        }
    } catch (error) {
        console.error('Error al repostear el post:', error); // Depuración
        res.json({ error: 'Error al repostear el post' });
    } finally {
        await session.close();
    }
});

// Nueva funcionalidad: Crear un comentario en un post
app.post('/comment', async (req, res) => {
    const { postId, userId, content } = req.body;

    console.log('Comment request received:', { postId, userId, content }); // Depuración

    const session = driver.session();
    try {
        const commentResult = await session.run(
            `MATCH (u:Usuario {id_usuario: $userId}), (p:Post {id_post: $postId})
             CREATE (c:Comentario {id_comentario: apoc.create.uuid(), content: $content, comment_date: datetime()})
             CREATE (u)-[:COMENTA]->(c)
             CREATE (p)-[:TIENE_COMENTARIO]->(c)
             RETURN c.id_comentario AS id_comentario`,
            { postId, userId, content }
        );

        const commentId = commentResult.records[0].get('id_comentario');

        res.json({ success: true, commentId: commentId });
    } catch (error) {
        console.error('Error creating comment:', error); // Depuración
        res.json({ error: 'Error creating comment' });
    } finally {
        await session.close();
    }
});

// Nueva funcionalidad: Obtener los comentarios de un post
app.get('/comments', async (req, res) => {
    const { postId } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (p:Post {id_post: $postId})-[:TIENE_COMENTARIO]->(c:Comentario)
             OPTIONAL MATCH (c)<-[:COMENTA]-(u:Usuario)
             OPTIONAL MATCH (u)-[:TIENE_IMAGEN_DE_PERFIL]->(profileImage:Imagen)
             RETURN c, u.user_name AS username, profileImage.url AS profileImageUrl
             ORDER BY c.comment_date ASC`,
            { postId }
        );

        const comments = result.records.length > 0 ? result.records.map(record => {
            const comment = record.get('c');
            const username = record.get('username');
            const profileImageUrl = record.get('profileImageUrl');

            const commentDate = comment.properties.comment_date;
            return {
                id_comentario: comment.properties.id_comentario,
                content: comment.properties.content,
                comment_date: commentDate ? new Date(commentDate.year.low, commentDate.month.low - 1, commentDate.day.low, commentDate.hour.low, commentDate.minute.low, commentDate.second.low, commentDate.nanosecond.low / 1000000).toISOString() : null,
                username: username,
                profileImageUrl: profileImageUrl
            };
        }) : [];

        res.json(comments);
    } catch (error) {
        console.error('Error fetching comments:', error);
        res.json([]);
    } finally {
        await session.close();
    }
});

app.get('/latestUsers', async (req, res) => {
    const session = driver.session();
    try {
        const result = await session.run(
            `MATCH (u:Usuario)
             OPTIONAL MATCH (u)-[:TIENE_IMAGEN_DE_PERFIL]->(img:Imagen)
             RETURN u.user_name AS username, img.url AS profileImage
             ORDER BY u.register_date DESC
             LIMIT 15`
        );

        const users = result.records.map(record => ({
            username: record.get('username'),
            profileImage: record.get('profileImage') || 'default_profile.gif' // Imagen de perfil predeterminada si no hay una imagen
        }));

        res.json(users);
    } catch (error) {
        console.error('Error fetching latest users:', error);
        res.status(500).json({ error: 'Error fetching latest users' });
    } finally {
        await session.close();
    }
});

app.delete('/deletePost', async (req, res) => {
    const { postId } = req.body;
    const session = driver.session();

    try {
        // Eliminar el post, comentarios y todas las relaciones asociadas
        await session.run(
            `MATCH (p:Post {id_post: $postId})
             OPTIONAL MATCH (p)-[:TIENE_COMENTARIO]->(c:Comentario)
             OPTIONAL MATCH (c)<-[relCom:COMENTA]-(:Usuario)
             DETACH DELETE p, c, relCom`, // Eliminar nodos y relaciones asociadas
            { postId }
        );

        res.json({ success: true });
    } catch (error) {
        console.error('Error deleting post:', error);
        res.json({ error: 'Error deleting post' });
    } finally {
        await session.close();
    }
});

// Llamar a la función para crear el nodo de imagen predeterminada al iniciar el servidor
getDefaultProfileImageNode();

app.listen(8080, '192.168.7.125', () => {
    console.log('Server is running on http://192.168.7.125:8080');
});

//app.listen(8080, '192.168.1.148', () => {
 //   console.log('Server is running on http://192.168.1.148:8080');
//});
