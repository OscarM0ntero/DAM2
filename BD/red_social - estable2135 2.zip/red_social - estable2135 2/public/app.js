// /mnt/data/app.js

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const postForm = document.getElementById('postForm');
    const editProfileForm = document.getElementById('editProfileForm');
    const logoutButton = document.getElementById('logoutButton');
    const myProfileButton = document.getElementById('myProfileButton');
    const followButton = document.getElementById('followButton');
    const editProfileButton = document.getElementById('editProfileButton');
    const backToFeedButton = document.getElementById('backToFeedButton');
    const backToProfileButton = document.getElementById('backToProfileButton');
    const searchUserButton = document.getElementById('searchUserButton');

    // Función para mostrar la sección correspondiente
    const showSection = (sectionId) => {
        document.querySelectorAll('body > div').forEach(div => {
            div.style.display = 'none';
        });
        document.getElementById(sectionId).style.display = 'block';
    };

    // Función para formatear la fecha y hora
    const formatDateTime = (dateTimeString) => {
        const date = new Date(dateTimeString);
        return date.toLocaleString();
    };

    // Función para manejar la eliminación de un post
    const deletePost = async (postId) => {
        try {
            const response = await fetch('/deletePost', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ postId })
            });
            const result = await response.json();
            if (result.success) {
                alert('Post eliminado con éxito.');
                const userId = localStorage.getItem('user_id');
                loadFeed(); // Recargar el feed
                loadUserProfile(userId, 'My Profile'); // Recargar el perfil del usuario
            } else {
                alert('Error al eliminar el post.');
            }
        } catch (error) {
            console.error('Error deleting post:', error);
            alert('An error occurred while deleting the post. Please try again.');
        }
    };

    // Función para cargar el feed
    const loadFeed = async () => {
        const user_id = localStorage.getItem('user_id');
        console.log("Usuario actual:", user_id); // Depuración

        try {
            const response = await fetch(`/feed?user_id=${user_id}`);
            const posts = await response.json();
            const postsContainer = document.getElementById('posts');
            postsContainer.innerHTML = '';

            // Añadir el formulario de creación de posts
            const createPostForm = document.createElement('form');
            createPostForm.id = 'postForm';
            createPostForm.enctype = 'multipart/form-data';
            createPostForm.innerHTML = `
                <textarea id="postContent" placeholder="¿Qué estás pensando?"></textarea>
                <input type="file" id="postImage" accept="image/*">
                <button type="submit">Publicar</button>
            `;
            postsContainer.appendChild(createPostForm);

            createPostForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                const content = document.getElementById('postContent').value;
                const user_id = localStorage.getItem('user_id');
                const postImage = document.getElementById('postImage').files[0];

                const formData = new FormData();
                formData.append('content', content);
                formData.append('user_id', user_id);
                if (postImage) {
                    formData.append('postImage', postImage);
                }

                try {
                    const response = await fetch('/post', {
                        method: 'POST',
                        body: formData
                    });
                    const result = await response.json();
                    if (result.success) {
                        document.getElementById('postContent').value = '';
                        document.getElementById('postImage').value = '';
                        loadFeed();
                    } else {
                        alert(result.error);
                    }
                } catch (error) {
                    console.error('Error during posting:', error);
                    alert('An error occurred during posting. Please try again.');
                }
            });

            posts.forEach(post => {
                if (post && post.id_post) { // Verificar que el post sea válido
                    console.log("Post ID:", post.id_post); // Depuración
                    console.log("Post User ID:", post.user_id); // Depuración

                    const postElement = document.createElement('div');
                    postElement.classList.add('post');
                    postElement.innerHTML = `
                        <div class="post-header">
                            <img src="${post.profileImage}" alt="Profile Image" class="profile-image">
                            <h3>${post.username}</h3>
                        </div>
                        <p class="post-content">${post.content}</p>
                        ${post.postImage ? `<img src="${post.postImage}" alt="Post Image" class="post-image">` : ''}
                        <small class="post-date">${formatDateTime(post.post_date)}</small>
                        <div class="post-buttons">
                            <button class="likeButton" data-post-id="${post.id_post}">${post.likedByUser ? 'Quitar Me gusta' : 'Me gusta'}</button>
                            <button class="repostButton" data-post-id="${post.id_post}">${post.repostedByUser ? 'Quitar Repost' : 'Repost'}</button>
                            ${post.user_id === user_id ? `<button class="deleteButton" data-post-id="${post.id_post}">Eliminar</button>` : ''}
                        </div>
                        <div class="comments" data-post-id="${post.id_post}"></div>
                        <form class="commentForm" data-post-id="${post.id_post}">
                            <input type="text" class="commentContent" placeholder="Escribe un comentario...">
                            <button type="submit">Comentar</button>
                        </form>
                    `;
                    const likeButton = postElement.querySelector('.likeButton');
                    const repostButton = postElement.querySelector('.repostButton');
                    const deleteButton = postElement.querySelector('.deleteButton');
                    likeButton.addEventListener('click', () => toggleLike(post.id_post, likeButton));
                    repostButton.addEventListener('click', () => toggleRepost(post.id_post, repostButton));
                    if (deleteButton) {
                        deleteButton.addEventListener('click', () => deletePost(post.id_post));
                    }

                    const commentForm = postElement.querySelector('.commentForm');
                    commentForm.addEventListener('submit', (e) => handleCommentSubmit(e, post.id_post));

                    postsContainer.appendChild(postElement);

                    // Cargar comentarios del post
                    loadComments(post.id_post);
                }
            });
            showSection('feed');
            loadLatestUsers(); // Cargar usuarios nuevos en la feed
        } catch (error) {
            console.error('Error loading feed:', error);
            alert('An error occurred while loading the feed. Please try again.');
        }
    };

    // Función para cargar el perfil del usuario
    const loadUserProfile = async (user_id, username) => {
        followButton.setAttribute('data-followee-id', user_id);
    
        try {
            const currentUserId = localStorage.getItem('user_id');
            const isCurrentUser = currentUserId === user_id;
            const response = await fetch(`/isFollowing?follower_id=${currentUserId}&followee_id=${user_id}`);
            const followStatus = await response.json();
            followButton.textContent = followStatus.isFollowing ? 'Unfollow' : 'Follow';
            followButton.setAttribute('data-following', followStatus.isFollowing);
            followButton.style.display = isCurrentUser ? 'none' : 'block';
            editProfileButton.style.display = isCurrentUser ? 'block' : 'none';
    
            const profileResponse = await fetch(`/user/profile?user_id=${user_id}`);
            const profile = await profileResponse.json();
    
            const userProfileName = document.getElementById('userProfileName');
            userProfileName.textContent = profile.username;
            const userProfileImage = document.getElementById('userProfileImage');
            userProfileImage.src = profile.profileImage;
            const userProfileBio = document.getElementById('userProfileBio');
            userProfileBio.textContent = profile.biography; // Añadir biografía al perfil
            const userProfilePosts = document.getElementById('userProfilePosts');
            userProfilePosts.innerHTML = '';
    
            const postsResponse = await fetch(`/user/posts?user_id=${user_id}`);
            const posts = await postsResponse.json();
    
            // Asegurarse de que posts sea un array
            if (Array.isArray(posts)) {
                posts.forEach(post => {
                    if (post && post.id_post) { // Verificar que el post sea válido
                        const postElement = document.createElement('div');
                        postElement.classList.add('post');
                        postElement.innerHTML = `
                            <div class="post-header">
                                <img src="${post.authorImage}" alt="Profile Image" class="profile-image">
                                <h3>${post.authorName}</h3>
                            </div>
                            <p class="post-content">${post.content}</p>
                            ${post.postImage ? `<img src="${post.postImage}" alt="Post Image" class="post-image">` : ''}
                            <small class="post-date">${formatDateTime(post.post_date)}</small>
                            ${post.relationshipType === 'LE_GUSTA' ? '<small>Le gustó este post</small>' : ''}
                            ${post.relationshipType === 'REPOSTEA' ? '<small>Reposteó este post</small>' : ''}
                            <div class="post-buttons">
                                <button class="likeButton" data-post-id="${post.id_post}">${post.likedByUser ? 'Quitar Me gusta' : 'Me gusta'}</button>
                                <button class="repostButton" data-post-id="${post.id_post}">${post.repostedByUser ? 'Quitar Repost' : 'Repost'}</button>
                                ${post.user_id === currentUserId ? `<button class="deleteButton" data-post-id="${post.id_post}">Eliminar</button>` : ''}
                            </div>
                            <div class="comments" data-post-id="${post.id_post}"></div>
                            <form class="commentForm" data-post-id="${post.id_post}">
                                <input type="text" class="commentContent" placeholder="Escribe un comentario...">
                                <button type="submit">Comentar</button>
                            </form>
                        `;
                        const likeButton = postElement.querySelector('.likeButton');
                        const repostButton = postElement.querySelector('.repostButton');
                        const deleteButton = postElement.querySelector('.deleteButton');
                        likeButton.addEventListener('click', () => toggleLike(post.id_post, likeButton));
                        repostButton.addEventListener('click', () => toggleRepost(post.id_post, repostButton));
                        if (deleteButton) {
                            deleteButton.addEventListener('click', () => deletePost(post.id_post));
                        }
    
                        const commentForm = postElement.querySelector('.commentForm');
                        commentForm.addEventListener('submit', (e) => handleCommentSubmit(e, post.id_post));
    
                        userProfilePosts.appendChild(postElement);
    
                        // Cargar comentarios del post
                        loadComments(post.id_post);
                    }
                });
            } else {
                console.error('Posts is not an array:', posts);
            }
    
            showSection('userProfile');
            loadLatestUsers(); // Cargar usuarios nuevos en el perfil
        } catch (error) {
            console.error('Error loading user profile:', error);
            alert('An error occurred while loading the user profile. Please try again.');
        }
    };
    

    // Función para manejar los "Me gusta"
    const toggleLike = async (postId, likeButton) => {
        const userId = localStorage.getItem('user_id');
        try {
            const response = await fetch('/like', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ postId, userId })
            });
            const result = await response.json();
            if (result.success) {
                likeButton.textContent = result.action === 'liked' ? 'Quitar Me gusta' : 'Me gusta';
            } else {
                alert('Error al dar "Me gusta" al post.');
            }
        } catch (error) {
            console.error('Error during liking the post:', error);
            alert('An error occurred while liking the post. Please try again.');
        }
    };

    // Función para manejar los "Reposts"
    const toggleRepost = async (postId, repostButton) => {
        const userId = localStorage.getItem('user_id');
        try {
            const response = await fetch('/repost', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ postId, userId })
            });
            const result = await response.json();
            if (result.success) {
                repostButton.textContent = result.action === 'reposted' ? 'Quitar Repost' : 'Repost';
            } else {
                alert('Error al repostear el post.');
            }
        } catch (error) {
            console.error('Error during reposting the post:', error);
            alert('An error occurred while reposting the post. Please try again.');
        }
    };

    // Función para manejar el envío de comentarios
    const handleCommentSubmit = async (e, postId) => {
        e.preventDefault();
        const userId = localStorage.getItem('user_id');
        const commentContent = e.target.querySelector('.commentContent').value;

        try {
            const response = await fetch('/comment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ postId, userId, content: commentContent })
            });
            const result = await response.json();
            if (result.success) {
                e.target.querySelector('.commentContent').value = '';
                loadComments(postId); // Recargar los comentarios del post
            } else {
                alert('Error al enviar el comentario.');
            }
        } catch (error) {
            console.error('Error during submitting the comment:', error);
            alert('An error occurred while submitting the comment. Please try again.');
        }
    };

    // Función para cargar los comentarios de un post
    const loadComments = async (postId) => {
        try {
            const response = await fetch(`/comments?postId=${postId}`);
            const comments = await response.json();
            const commentsContainer = document.querySelector(`.comments[data-post-id="${postId}"]`);
            commentsContainer.innerHTML = '';

            comments.forEach(comment => {
                const commentElement = document.createElement('div');
                commentElement.classList.add('comment');
                commentElement.innerHTML = `
                    <strong class="comment-author">${comment.username}</strong>
                    <p class="comment-content">${comment.content}</p>
                    <small class="comment-date">${formatDateTime(comment.comment_date)}</small>
                `;
                commentsContainer.appendChild(commentElement);
            });
        } catch (error) {
            console.error('Error loading comments:', error);
            alert('An error occurred while loading the comments. Please try again.');
        }
    };

    // Función para buscar un usuario
    const searchUser = async () => {
        const username = document.getElementById('searchUserInput').value;

        try {
            const response = await fetch(`/user?username=${username}`);
            const user = await response.json();
            if (user.error) {
                alert('Usuario no encontrado');
            } else {
                loadUserProfile(user.id_usuario, user.user_name);
            }
        } catch (error) {
            console.error('Error searching user:', error);
            alert('An error occurred while searching for the user. Please try again.');
        }
    };

    // Función para cargar la lista de últimos usuarios
    const loadLatestUsers = async () => {
        try {
            const response = await fetch('/latestUsers');
            const users = await response.json();
            const latestUsersList = document.getElementById('latestUsersList');
            latestUsersList.innerHTML = '';
            const latestUsersListProfile = document.getElementById('latestUsersListProfile');
            latestUsersListProfile.innerHTML = '';

            users.forEach(user => {
                const userElement = document.createElement('li');
                userElement.innerHTML = `
                    <img src="${user.profileImage}" alt="Profile Image" class="latest-user-profile-image">
                    <span>${user.username}</span>
                `;
                userElement.addEventListener('click', () => loadUserProfile(user.id_usuario, user.username));
                latestUsersList.appendChild(userElement);
                latestUsersListProfile.appendChild(userElement.cloneNode(true));
            });
        } catch (error) {
            console.error('Error loading latest users:', error);
            alert('An error occurred while loading the latest users. Please try again.');
        }
    };

    // Eventos de botones
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;

        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            const result = await response.json();
            if (result.id_usuario) {
                localStorage.setItem('user_id', result.id_usuario);
                loadFeed();
            } else {
                alert('Credenciales inválidas');
            }
        } catch (error) {
            console.error('Error during login:', error);
            alert('An error occurred during login. Please try again.');
        }
    });

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const biography = document.getElementById('biography').value;
        const profileImage = document.getElementById('profileImage').files[0];

        const formData = new FormData();
        formData.append('username', username);
        formData.append('password', password);
        formData.append('biography', biography);
        if (profileImage) {
            formData.append('profileImage', profileImage);
        }

        try {
            const response = await fetch('/register', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();
            if (result.success) {
                alert('Registro exitoso. Por favor, inicia sesión.');
                showSection('login');
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Error during registration:', error);
            alert('An error occurred during registration. Please try again.');
        }
    });

    editProfileForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const user_id = localStorage.getItem('user_id');
        const username = document.getElementById('editUsername').value;
        const biography = document.getElementById('editBiography').value;
        const profileImage = document.getElementById('editProfileImage').files[0];

        const formData = new FormData();
        formData.append('user_id', user_id);
        formData.append('username', username);
        formData.append('biography', biography);
        if (profileImage) {
            formData.append('profileImage', profileImage);
        }

        try {
            const response = await fetch('/editProfile', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();
            if (result.success) {
                alert('Perfil actualizado con éxito.');
                loadUserProfile(user_id, 'My Profile');
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Error during profile update:', error);
            alert('An error occurred during profile update. Please try again.');
        }
    });

    logoutButton.addEventListener('click', () => {
        localStorage.removeItem('user_id');
        showSection('login');
    });

    myProfileButton.addEventListener('click', () => {
        const user_id = localStorage.getItem('user_id');
        loadUserProfile(user_id, 'My Profile');
    });

    followButton.addEventListener('click', async () => {
        const userId = localStorage.getItem('user_id');
        const followeeId = followButton.getAttribute('data-followee-id');
        const isFollowing = followButton.getAttribute('data-following') === 'true';

        try {
            if (isFollowing) {
                await fetch('/unfollow', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ follower_id: userId, followee_id: followeeId })
                });
                followButton.textContent = 'Follow';
                followButton.setAttribute('data-following', 'false');
            } else {
                await fetch('/follow', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ follower_id: userId, followee_id: followeeId })
                });
                followButton.textContent = 'Unfollow';
                followButton.setAttribute('data-following', 'true');
            }
        } catch (error) {
            console.error('Error during follow/unfollow:', error);
            alert('An error occurred while trying to follow/unfollow the user. Please try again.');
        }
    });

    editProfileButton.addEventListener('click', () => {
        const userId = localStorage.getItem('user_id');
        loadUserProfile(userId, 'Edit Profile');
        showSection('editProfile');
    });

    backToFeedButton.addEventListener('click', () => {
        loadFeed();
    });

    backToProfileButton.addEventListener('click', () => {
        const userId = localStorage.getItem('user_id');
        loadUserProfile(userId, 'My Profile');
    });

    searchUserButton.addEventListener('click', searchUser);

    // Inicializar la carga del feed
    const init = () => {
        const userId = localStorage.getItem('user_id');
        if (userId) {
            loadFeed();
        } else {
            showSection('login');
        }
    };

    init();
});
