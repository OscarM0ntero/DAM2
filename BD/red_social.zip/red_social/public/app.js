document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    const loginForm = document.getElementById('loginForm');
    const postForm = document.getElementById('postForm');
    const searchUserButton = document.getElementById('searchUserButton');
    const logoutButton = document.getElementById('logoutButton');
    const backToFeedButton = document.getElementById('backToFeedButton');
    const goToRegister = document.getElementById('goToRegister');
    const goToLogin = document.getElementById('goToLogin');

    const showSection = (sectionId) => {
        document.getElementById('login').style.display = 'none';
        document.getElementById('register').style.display = 'none';
        document.getElementById('feed').style.display = 'none';
        document.getElementById('userProfile').style.display = 'none';
        document.getElementById(sectionId).style.display = 'block';
    };

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const biography = document.getElementById('biography').value;

        try {
            const response = await fetch('/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password, biography })
            });
            const result = await response.json();
            if (result.success) {
                alert('Registration successful! Please login.');
                showSection('login');
            } else {
                alert(result.error);
            }
        } catch (error) {
            alert('An error occurred during registration. Please try again.');
        }
    });

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;

        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            const result = await response.json();
            if (result.id_usuario) {
                localStorage.setItem('user_id', result.id_usuario);
                loadFeed();
            } else {
                alert(result.error);
            }
        } catch (error) {
            alert('An error occurred during login. Please try again.');
        }
    });

    postForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const content = document.getElementById('postContent').value;
        const user_id = localStorage.getItem('user_id');

        try {
            const response = await fetch('/post', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ content, user_id })
            });
            const result = await response.json();
            if (result.success) {
                document.getElementById('postContent').value = '';
                loadFeed();
            } else {
                alert(result.error);
            }
        } catch (error) {
            alert('An error occurred during posting. Please try again.');
        }
    });

    searchUserButton.addEventListener('click', async () => {
        const username = document.getElementById('searchUserInput').value;

        try {
            const response = await fetch(`/user?username=${username}`);
            const user = await response.json();
            if (user.id_usuario) {
                loadUserProfile(user.id_usuario, user.user_name);
            } else {
                alert(user.error);
            }
        } catch (error) {
            alert('An error occurred while searching for the user. Please try again.');
        }
    });

    logoutButton.addEventListener('click', () => {
        localStorage.removeItem('user_id');
        showSection('login');
    });

    backToFeedButton.addEventListener('click', () => {
        loadFeed();
    });

    const loadFeed = async () => {
        const user_id = localStorage.getItem('user_id');

        try {
            const response = await fetch(`/feed?user_id=${user_id}`);
            const posts = await response.json();
            const postsContainer = document.getElementById('posts');
            postsContainer.innerHTML = '';
            posts.forEach(post => {
                const postElement = document.createElement('div');
                postElement.innerHTML = `<p>${post.content}</p><small>${post.post_date}</small>`;
                postsContainer.appendChild(postElement);
            });
            showSection('feed');
        } catch (error) {
            alert('An error occurred while loading the feed. Please try again.');
        }
    };

    const loadUserProfile = async (user_id, username) => {
        try {
            const response = await fetch(`/user/posts?user_id=${user_id}`);
            const posts = await response.json();
            const userProfileName = document.getElementById('userProfileName');
            userProfileName.textContent = username;
            const userProfilePosts = document.getElementById('userProfilePosts');
            userProfilePosts.innerHTML = '';
            posts.forEach(post => {
                const postElement = document.createElement('div');
                postElement.innerHTML = `<p>${post.content}</p><small>${post.post_date}</small>`;
                userProfilePosts.appendChild(postElement);
            });
            showSection('userProfile');
        } catch (error) {
            alert('An error occurred while loading the user profile. Please try again.');
        }
    };

    // Show login form by default
    showSection('login');

    goToRegister.addEventListener('click', () => showSection('register'));
    goToLogin.addEventListener('click', () => showSection('login'));
});
