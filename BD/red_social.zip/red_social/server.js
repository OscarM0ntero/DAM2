const express = require('express');
const bodyParser = require('body-parser');
const driver = require('./neo4j_driver');

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.post('/register', async (req, res) => {
    const { username, password, biography } = req.body;
    const session = driver.session();

    try {
        const result = await session.run(
            `CREATE (u:Usuario {id_usuario: apoc.create.uuid(), user_name: $username, password: $password, biography: $biography, register_date: datetime()}) RETURN u`,
            { username, password, biography }
        );
        res.json({ success: true });
    } catch (error) {
        res.json({ error: 'Error during registration' });
    } finally {
        await session.close();
    }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {user_name: $username, password: $password}) RETURN u.id_usuario AS id_usuario`,
            { username, password }
        );

        if (result.records.length > 0) {
            res.json({ id_usuario: result.records[0].get('id_usuario') });
        } else {
            res.json({ error: 'Invalid credentials' });
        }
    } catch (error) {
        res.json({ error: 'Error during login' });
    } finally {
        await session.close();
    }
});

app.post('/post', async (req, res) => {
    const { content, user_id } = req.body;
    const session = driver.session();

    try {
        await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})
             CREATE (p:Post {id_post: apoc.create.uuid(), content: $content, post_date: datetime()})
             MERGE (u)-[:PUBLICA]->(p)`,
            { content, user_id }
        );
        res.json({ success: true });
    } catch (error) {
        res.json({ error: 'Error during posting' });
    } finally {
        await session.close();
    }
});

app.get('/feed', async (req, res) => {
    const { user_id } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario)-[:SIGUE]->(f:Usuario)-[:PUBLICA]->(p:Post)
             WHERE u.id_usuario = $user_id
             RETURN p.content AS content, p.post_date AS post_date`,
            { user_id }
        );

        const posts = result.records.map(record => ({
            content: record.get('content'),
            post_date: record.get('post_date').toString()
        }));

        res.json(posts);
    } catch (error) {
        res.json({ error: 'Error loading feed' });
    } finally {
        await session.close();
    }
});

app.get('/user', async (req, res) => {
    const { username } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {user_name: $username}) RETURN u`,
            { username }
        );

        if (result.records.length > 0) {
            const user = result.records[0].get('u').properties;
            res.json(user);
        } else {
            res.json({ error: 'User not found' });
        }
    } catch (error) {
        res.json({ error: 'Error searching for user' });
    } finally {
        await session.close();
    }
});

app.get('/user/posts', async (req, res) => {
    const { user_id } = req.query;
    const session = driver.session();

    try {
        const result = await session.run(
            `MATCH (u:Usuario {id_usuario: $user_id})-[:PUBLICA]->(p:Post)
             RETURN p.content AS content, p.post_date AS post_date`,
            { user_id }
        );

        const posts = result.records.map(record => ({
            content: record.get('content'),
            post_date: record.get('post_date').toString()
        }));

        res.json(posts);
    } catch (error) {
        res.json({ error: 'Error loading user posts' });
    } finally {
        await session.close();
    }
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
