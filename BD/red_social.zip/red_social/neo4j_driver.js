// neo4j_driver.js

const neo4j = require('neo4j-driver');

const driver = neo4j.driver(
    'bolt://localhost:7687', // URL del servidor Neo4j
    neo4j.auth.basic('neo4j', '12345678'),  // Reemplaza 'your_password_here' con la contraseña de tu base de datos Neo4j
    { encrypted: 'ENCRYPTION_OFF' } 
);

module.exports = driver;
