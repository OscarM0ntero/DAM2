/**
 * 
 */
/**
 * 
 */
module AD202_BBDDLoginDeUsuarios {
	requires java.sql;
}