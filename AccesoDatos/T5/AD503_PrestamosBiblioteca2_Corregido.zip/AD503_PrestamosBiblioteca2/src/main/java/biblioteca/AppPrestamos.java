package biblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppPrestamos {
    public static void main(String[] args) {
        SpringApplication.run(AppPrestamos.class, args);
    }
}
