/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: omontero <omontero@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/31 12:05:21 by omontero          #+#    #+#             */
/*   Updated: 2022/05/31 12:07:49 by omontero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

/* int	main(void)
{
	int		fd;
	int		i;
	char	*c;

	i = 0;
	fd = open("lines_around_10.txt", O_RDONLY);
	while (i < 10)
	{
		c = get_next_line(fd);
		printf(">%s<\n", c);
		free (c);
		i++;
	}
	close(fd);
} */

/* int	main(void)
{
	int		fd;
	int		i;
	char	*c;

	i = 0;
	fd = open("file.txt", O_RDONLY);
	while (i < 10)
	{
		c = get_next_line(fd);
		printf(">%s<\n", c);
		free (c);
		i++;
	}
	close(fd);
} */

/* int	main(void)
{
	int		fd;
	int		i;
	char	*c;

	i = 0;
	fd = open("file2.txt", O_RDONLY);
	while (i < 10)
	{
		c = get_next_line(fd);
		printf(">%s<\n", c);
		free (c);
		i++;
	}
	close(fd);
} */