import { EdadPipe } from './edad.pipe';

describe('EdadPipe', () => {
  it('create an instance', () => {
    const pipe = new EdadPipe();
    expect(pipe).toBeTruthy();
  });
});
