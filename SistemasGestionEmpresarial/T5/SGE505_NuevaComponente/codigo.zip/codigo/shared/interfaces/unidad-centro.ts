export interface UnidadCentro {
	id_unidad_centro: number;
	unidad_centro: String;
	id_ciclo: number;
	observaciones?: any;
  }
  