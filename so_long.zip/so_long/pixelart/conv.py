import sys
import glob
import os

def convert_newlines(directory):
    # Buscar archivos .xpm42 en la carpeta especificada
    files = glob.glob(os.path.join(directory, "*.xpm42"))
    
    for file in files:
        with open(file, "rb") as f:
            content = f.read()
        
        # Reemplazar \r\n por \n
        new_content = content.replace(b"\r\n", b"\n")
        
        # Guardar solo si hubo cambios
        if new_content != content:
            with open(file, "wb") as f:
                f.write(new_content)
            print(f"Convertido: {file}")
        else:
            print(f"Sin cambios: {file}")

if __name__ == "__main__":
    # Obtener el directorio actual o el especificado por el usuario
    directory = sys.argv[1] if len(sys.argv) > 1 else os.getcwd()
    convert_newlines(directory)

