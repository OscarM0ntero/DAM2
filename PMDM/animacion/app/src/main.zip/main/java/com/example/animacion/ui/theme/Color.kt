package com.example.animacion.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val Green80 = Color(0xFF68806A)
val  DarkGreen80 = Color(0xFF4A5A47)
val LightGreen80 = Color(0xFF9A9E90)

val Green40 = Color(0xFF68806A)
val DarkGreen40 = Color(0xFF8A9A7B)
val LightGreen40 = Color(0xFFB7C4A1)
